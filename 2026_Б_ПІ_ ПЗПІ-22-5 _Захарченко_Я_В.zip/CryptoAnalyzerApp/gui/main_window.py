# gui/main_window.py
from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout,
                             QGridLayout, QTextEdit, QPushButton, QLabel,
                             QComboBox, QFileDialog, QMessageBox, QGroupBox)
from PyQt6.QtCore import Qt

from core.crypto_core import classify_cipher
from core.vigenere import crack_vigenere
from core.caesar import crack_caesar
from core.file_manager import read_text_file, write_text_file

# Сучасний темний стиль (QSS) для нашого додатка
STYLE_SHEET = """
QMainWindow {
    background-color: #121824;
}

QGroupBox {
    background-color: #1c2333;
    border: 1px solid #2d3748;
    border-radius: 8px;
    margin-top: 12px;
    font-weight: bold;
    font-size: 13px;
    color: #e2e8f0;
    padding-top: 15px;
}

QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 10px;
    padding: 0 5px;
    color: #3b82f6;
}

QLabel {
    color: #94a3b8;
    font-size: 12px;
}

QTextEdit {
    background-color: #0f141c;
    border: 1px solid #2d3748;
    border-radius: 6px;
    color: #f1f5f9;
    font-family: "Consolas", "Courier New", monospace;
    font-size: 13px;
    padding: 8px;
}

QTextEdit:focus {
    border: 1px solid #3b82f6;
}

QComboBox {
    background-color: #0f141c;
    border: 1px solid #2d3748;
    border-radius: 6px;
    color: #f1f5f9;
    padding: 5px 10px;
    min-width: 120px;
}

QComboBox::drop-down {
    border: none;
}

QPushButton {
    background-color: #1e293b;
    border: 1px solid #334155;
    border-radius: 6px;
    color: #f1f5f9;
    font-weight: bold;
    padding: 8px 15px;
}

QPushButton:hover {
    background-color: #334155;
    border-color: #475569;
}

QPushButton:pressed {
    background-color: #0f172a;
}

QPushButton#btn_analyze {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #2563eb, stop:1 #1d4ed8);
    border: none;
    color: white;
    font-size: 13px;
}

QPushButton#btn_analyze:hover {
    background: qlineargradient(x1:0, y1:0, x2:1, y2:0, stop:0 #3b82f6, stop:1 #2563eb);
}

QPushButton#btn_analyze:pressed {
    background: #1e40af;
}

QPushButton:disabled {
    background-color: #0f141c;
    color: #475569;
    border-color: #1e293b;
}
"""


class CryptoAnalyzerApp(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("CryptoAnalyzer — Автоматизований криптоаналіз")
        self.setMinimumSize(1000, 700)

        # Застосовуємо наш кастомний стиль
        self.setStyleSheet(STYLE_SHEET)
        self.init_ui()

    def init_ui(self):
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        main_layout = QVBoxLayout(main_widget)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(12)

        # Заголовок програми
        title_lbl = QLabel("ЦЕНТР АВТОМАТИЗОВАНОГО КРИПТОАНАЛІЗУ СИСТЕМ ПІДСТАНОВКИ")
        title_lbl.setStyleSheet("font-size: 16px; font-weight: bold; color: #f8fafc; letter-spacing: 1px;")
        title_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
        main_layout.addWidget(title_lbl)

        content_layout = QHBoxLayout()
        main_layout.addLayout(content_layout)

        # ================= ЛІВА ПАНЕЛЬ =================
        left_panel = QGroupBox("ВХІДНІ ДАНІ ТА КЕРУВАННЯ")
        left_layout = QVBoxLayout(left_panel)
        left_layout.setSpacing(10)

        # Вибір мови та режиму аналізу
        control_grid = QGridLayout()
        control_grid.addWidget(QLabel("Робоча мова тексту:"), 0, 0)
        self.lang_box = QComboBox()
        self.lang_box.addItems(["english", "ukrainian"])
        control_grid.addWidget(self.lang_box, 0, 1)

        control_grid.addWidget(QLabel("Режим аналізу:"), 1, 0)
        self.mode_box = QComboBox()
        self.mode_box.addItems(["Автовизначення (IC)", "Примусово Цезар", "Примусово Віженер"])
        control_grid.addWidget(self.mode_box, 1, 1)
        left_layout.addLayout(control_grid)

        self.btn_open_file = QPushButton("📂 Завантажити шифротекст з файлу (.txt)")
        self.btn_open_file.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_open_file.clicked.connect(self.open_file)
        left_layout.addWidget(self.btn_open_file)

        left_layout.addWidget(QLabel("Перехоплений шифротекст:"))
        self.input_text = QTextEdit()
        self.input_text.setPlaceholderText("Вставте зашифрований текст сюди або завантажте файл...")
        left_layout.addWidget(self.input_text)

        self.btn_analyze = QPushButton("⚡ Запустити інтелектуальний аналіз")
        self.btn_analyze.setObjectName("btn_analyze")  # Прив'язка до стилю градієнта
        self.btn_analyze.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_analyze.clicked.connect(self.process_analysis)
        left_layout.addWidget(self.btn_analyze)

        content_layout.addWidget(left_panel, stretch=1)

        # !!! ЗАЙВИЙ ШМАТОК КОДУ ТУТ УСПІШНО ВИДАЛЕНО !!!

        # ================= ПРАВА ПАНЕЛЬ =================
        right_panel = QGroupBox("РЕЗУЛЬТАТИ ТА КРИПТОАНАЛІТИКА")
        right_layout = QVBoxLayout(right_panel)
        right_layout.setSpacing(10)

        diag_layout = QGridLayout()
        diag_layout.setHorizontalSpacing(20)
        diag_layout.setVerticalSpacing(10)

        diag_layout.addWidget(QLabel("Розрахований Індекс Збігу ($IC$):"), 0, 0)
        self.lbl_ic = QLabel("0.0000")
        self.lbl_ic.setStyleSheet("font-size: 14px; font-weight: bold; color: #3b82f6; font-family: monospace;")
        diag_layout.addWidget(self.lbl_ic, 0, 1)

        diag_layout.addWidget(QLabel("Аналітичний вердикт системи:"), 1, 0)
        self.lbl_cipher_type = QLabel("Очікування даних...")
        self.lbl_cipher_type.setStyleSheet("font-size: 12px; font-weight: bold; color: #eab308;")
        diag_layout.addWidget(self.lbl_cipher_type, 1, 1)
        right_layout.addLayout(diag_layout)

        key_box = QWidget()
        key_box.setStyleSheet("background-color: #0f141c; border-radius: 6px; border: 1px dashed #334155;")
        key_box_layout = QHBoxLayout(key_box)
        key_box_layout.addWidget(QLabel("ВІДНОВЛЕНИЙ КЛЮЧ ШИФРУ:"))
        self.lbl_recovered_key = QLabel("—")
        self.lbl_recovered_key.setStyleSheet(
            "font-size: 16px; font-weight: bold; color: #10b981; font-family: monospace; border: none;")
        key_box_layout.addWidget(self.lbl_recovered_key)
        key_box_layout.addStretch()
        right_layout.addWidget(key_box)

        right_layout.addWidget(QLabel("Дешифрований оригінальний текст:"))
        self.output_text = QTextEdit()
        self.output_text.setReadOnly(True)
        right_layout.addWidget(self.output_text)

        self.btn_save_file = QPushButton("💾 Експортувати дешифрований текст у файл")
        self.btn_save_file.setEnabled(False)
        self.btn_save_file.setCursor(Qt.CursorShape.PointingHandCursor)
        self.btn_save_file.clicked.connect(self.save_file)
        right_layout.addWidget(self.btn_save_file)

        content_layout.addWidget(right_panel, stretch=1)

    # ================= ЛОГІКА ВЗАЄМОДІЇ З GUI =================

    def open_file(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Відкрити шифротекст", "", "Text Files (*.txt);;All Files (*)")
        if file_path:
            try:
                content = read_text_file(file_path)
                self.input_text.setText(content)
            except Exception as e:
                QMessageBox.critical(self, "Помилка", f"Не вдалося прочитати файл:\n{str(e)}")

    def save_file(self):
        file_path, _ = QFileDialog.getSaveFileName(self, "Зберегти дешифрований текст", "",
                                                   "Text Files (*.txt);;All Files (*)")
        if file_path:
            try:
                write_text_file(file_path, self.output_text.toPlainText())
                QMessageBox.information(self, "Успіх", "Результат успішно збережено!")
            except Exception as e:
                QMessageBox.critical(self, "Помилка", f"Не вдалося зберегти файл:\n{str(e)}")

    def process_analysis(self):
        text = self.input_text.toPlainText().strip()
        lang = self.lang_box.currentText()
        selected_mode = self.mode_box.currentText()

        if not text:
            QMessageBox.warning(self, "Увага", "Будь ласка, введіть або завантажте шифротекст!")
            return

        try:
            # 1. Аналіз
            analysis = classify_cipher(text, lang)
            self.lbl_ic.setText(f"{analysis['ic']:.5f}")

            # 2. Логіка вибору
            run_caesar = False
            if selected_mode == "Примусово Цезар":
                run_caesar = True
                self.lbl_cipher_type.setText("Моноалфавітна (Цезар)")
            elif selected_mode == "Примусово Віженер":
                run_caesar = False
                self.lbl_cipher_type.setText("Поліалфавітна (Віженер)")
            else:
                run_caesar = "Моноалфавітний" in analysis["cipher_type"]
                self.lbl_cipher_type.setText(analysis["cipher_type"])

            # 3. ВИКОНАННЯ (тепер на правильному рівні відступів!)
            if run_caesar:
                result = crack_caesar(text, lang)
                if result:
                    self.lbl_recovered_key.setText(f"ЗСУВ: {result.get('shift', 0)}")
                    self.output_text.setText(result.get('text', ''))
            else:
                result = crack_vigenere(text, lang)
                if result:
                    self.lbl_recovered_key.setText(f"КЛЮЧ: '{result.get('recovered_key', 'Помилка')}'")
                    self.output_text.setText(result.get('decrypted_text', ''))

            self.btn_save_file.setEnabled(True)

        except Exception as e:
            QMessageBox.critical(self, "Помилка аналізу", f"Сталася помилка:\n{str(e)}")