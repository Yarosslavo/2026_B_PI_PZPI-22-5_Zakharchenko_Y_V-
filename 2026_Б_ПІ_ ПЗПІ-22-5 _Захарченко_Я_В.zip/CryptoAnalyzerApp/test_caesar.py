# test_caesar.py

# Базовий алфавіт (як у тебе в проекті)
alphabet = "абвгґдеєжзиійклмнопрстуфхцчшщьюя"
m = len(alphabet)

def shift_char(char, shift):
    char_lower = char.lower()
    if char_lower in alphabet:
        orig_idx = alphabet.index(char_lower)
        new_idx = (orig_idx - shift) % m  # Віднімаємо зсув для дешифрування
        new_char = alphabet[new_idx]
        return new_char.upper() if char.isupper() else new_char
    return char

def decrypt(text, shift):
    return "".join([shift_char(c, shift) for c in text])

# --- ТЕСТУЄМО ---
text = "Привіт"
shift = 3
# Шифруємо вручну (додаємо зсув)
encrypted = "".join([alphabet[(alphabet.index(c.lower()) + shift) % m] for c in text])

print(f"Оригінал: {text}")
print(f"Зашифровано (зсув 3): {encrypted}")
print(f"Розшифровано (зсув 3): {decrypt(encrypted, 3)}")

if decrypt(encrypted, 3).lower() == text.lower():
    print("✅ ТЕСТ ПРОЙДЕНО: Алфавіт та зсув працюють коректно!")
else:
    print("❌ ТЕСТ ПРОВАЛЕНО: Математика зсуву ламається.")