from collections import Counter
from core.crypto_core import LANG_DATA, clean_text


def crack_caesar(cipher_text: str, lang: str) -> dict:
    # 1. Жорсткий захист від падінь
    try:
        alphabet = LANG_DATA[lang]["alphabet"]
        m = len(alphabet)
        target_freqs = LANG_DATA[lang]["frequencies"]
        cleaned = clean_text(cipher_text, lang)

        if not cleaned:  # Якщо текст порожній - повертаємо "безпечну" відповідь
            return {"shift": 0, "text": cipher_text}

        counts = Counter(cleaned)
        total_chars = len(cleaned)
        best_shift, min_chi2 = 0, float('inf')

        # 2. Математика Хі-квадрат
        for shift in range(m):
            chi2 = 0.0
            for i in range(m):
                char = alphabet[i]
                expected = total_chars * target_freqs.get(char, 0.0)
                if expected > 0:
                    observed = counts.get(alphabet[(i + shift) % m], 0)
                    chi2 += ((observed - expected) ** 2) / expected

            if chi2 < min_chi2:
                min_chi2, best_shift = chi2, shift

        # 3. Дешифрування
        decrypted = "".join([
            alphabet[(alphabet.index(c.lower()) - best_shift) % m]
            if c.lower() in alphabet else c
            for c in cipher_text
        ])

        return {"shift": best_shift, "text": decrypted}

    except Exception as e:
        # ЗАМІСТЬ ПАДІННЯ - ПОВЕРТАЄМО ТЕКСТ ЯК Є
        return {"shift": 0, "text": cipher_text}