# core/crypto_core.py
import json
import os
from collections import Counter

def load_language_data():
    current_dir = os.path.dirname(os.path.abspath(__file__))
    json_path = os.path.join(current_dir, '..', 'data', 'languages.json')
    try:
        with open(json_path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except Exception:
        return LANG_DATA

LANG_DATA = {
    "ukrainian": {
        "alphabet": "абвгґдеєжзиійклмнопрстуфхцчшщьюя",
        "expected_ic": 0.0492,
        "frequencies": {
            'а': 0.072, 'б': 0.017, 'в': 0.052, 'г': 0.016, 'ґ': 0.001,
            'д': 0.035, 'е': 0.046, 'є': 0.008, 'ж': 0.009, 'з': 0.024,
            'и': 0.061, 'і': 0.057, 'ї': 0.006, 'й': 0.012, 'к': 0.035,
            'л': 0.036, 'м': 0.031, 'н': 0.065, 'о': 0.094, 'п': 0.029,
            'р': 0.047, 'с': 0.041, 'т': 0.055, 'у': 0.040, 'ф': 0.003,
            'х': 0.012, 'ц': 0.006, 'ч': 0.014, 'ш': 0.012, 'щ': 0.005,
            'ь': 0.016, 'ю': 0.008, 'я': 0.024
        }
    },
    "english": {
        "alphabet": "abcdefghijklmnopqrstuvwxyz",
        "expected_ic": 0.0667,
        "frequencies": {
            'a': 0.0817, 'b': 0.0149, 'c': 0.0278, 'd': 0.0425, 'e': 0.1270,
            'f': 0.0223, 'g': 0.0202, 'h': 0.0609, 'i': 0.0697, 'j': 0.0015,
            'k': 0.0077, 'l': 0.0403, 'm': 0.0241, 'n': 0.0675, 'o': 0.0751,
            'p': 0.0193, 'q': 0.0010, 'r': 0.0599, 's': 0.0633, 't': 0.0906,
            'u': 0.0276, 'v': 0.0098, 'w': 0.0236, 'x': 0.0015, 'y': 0.0197,
            'z': 0.0007
        }
    }
}

# Заміни цю функцію у core/crypto_core.py
def clean_text(text, lang):
    if not text:
        return "а" # Заглушка, щоб алгоритм не ділив на 0
    alphabet = LANG_DATA[lang]["alphabet"]
    cleaned = "".join([c.lower() for c in text if c.lower() in alphabet])
    return cleaned if cleaned else "а" # Якщо після чистки порожньо, повертаємо "а"

def calculate_ic(text: str, lang: str) -> float:
    cleaned = clean_text(text, lang)
    n = len(cleaned)
    if n <= 1:
        return 0.0
    counts = Counter(cleaned)
    numerator = sum(count * (count - 1) for count in counts.values())
    denominator = n * (n - 1)
    return numerator / denominator

def classify_cipher(text: str, lang: str) -> dict:
    ic = calculate_ic(text, lang)
    threshold = 0.043 if lang == "ukrainian" else 0.055
    if ic >= threshold:
        cipher_type = "Моноалфавітний шифр (напр. Цезар, проста підстановка)"
        action = "Рекомендовано: Частотний аналіз або повний перебір (Brute-Force)"
    else:
        cipher_type = "Поліалфавітний шифр (напр. Віженер)"
        action = "Рекомендовано: Визначення довжини ключа"
    return {"ic": round(ic, 5), "cipher_type": cipher_type, "action": action}