# core/vigenere.py
from collections import Counter
from core.crypto_core import LANG_DATA, clean_text


def crack_vigenere(cipher_text: str, lang: str) -> dict:
    """
    Повноцінний криптоаналіз шифру Віженера з захистом від помилок.
    """
    # 1. Захист: валідація мови та тексту
    if lang not in LANG_DATA:
        raise ValueError(f"Мова {lang} не підтримується.")

    cleaned = clean_text(cipher_text, lang)
    if not cleaned:
        return {"guessed_key_length": 1, "recovered_key": "", "decrypted_text": cipher_text}

    alphabet = LANG_DATA[lang]["alphabet"]
    target_freqs = LANG_DATA[lang]["frequencies"]
    m = len(alphabet)

    results_by_length = {}
    max_search_length = min(10, len(cleaned) // 2) if len(cleaned) > 2 else 1

    # 2. Основний цикл пошуку довжини
    for length in range(1, max_search_length + 1):
        slices = [[] for _ in range(length)]
        for idx, char in enumerate(cleaned):
            slices[idx % length].append(char)

        current_key = ""
        total_chi2 = 0.0

        for sub_list in slices:
            if not sub_list:
                current_key += alphabet[0]
                continue

            sub_len = len(sub_list)
            counts = Counter(sub_list)

            best_shift = 0
            min_sub_chi2 = float('inf')

            for shift in range(m):
                chi2 = 0.0
                for i in range(m):
                    char_at_i = alphabet[i]
                    expected = sub_len * target_freqs.get(char_at_i, 0.0)
                    if expected > 0:
                        observed = counts.get(alphabet[(i + shift) % m], 0)
                        chi2 += ((observed - expected) ** 2) / expected

                if chi2 < min_sub_chi2:
                    min_sub_chi2 = chi2
                    best_shift = shift

            current_key += alphabet[best_shift]
            total_chi2 += min_sub_chi2

        # Нормалізація з анти-кратним штрафом
        avg_chi2 = (total_chi2 / length) * (1 + length * 0.05)
        results_by_length[length] = {"key": current_key, "avg_chi2": avg_chi2}

    # 3. Вибір довжини з фільтром кратності
    best_length = min(results_by_length.keys(), key=lambda k: results_by_length[k]["avg_chi2"])

    # Фільтр: якщо менша довжина майже така ж хороша, беремо її
    min_score = results_by_length[best_length]["avg_chi2"]
    for length in sorted(results_by_length.keys()):
        if length < best_length and best_length % length == 0:
            if results_by_length[length]["avg_chi2"] <= min_score * 1.5:
                best_length = length
                break

    best_key = results_by_length[best_length]["key"]

    # 4. Дешифрування
    decrypted_chars = []
    key_idx = 0
    for char in cipher_text:
        char_lower = char.lower()
        if char_lower in alphabet:
            orig_idx = alphabet.index(char_lower)
            key_char = best_key[key_idx % best_length]
            key_shift = alphabet.index(key_char)
            new_idx = (orig_idx - key_shift) % m
            decrypted_char = alphabet[new_idx]
            decrypted_chars.append(decrypted_char if char.islower() else decrypted_char.upper())
            key_idx += 1
        else:
            decrypted_chars.append(char)

    return {
        "guessed_key_length": best_length,
        "recovered_key": best_key,
        "decrypted_text": "".join(decrypted_chars)
    }