import os


def read_text_file(file_path: str, encoding: str = 'utf-8') -> str:

    if not os.path.exists(file_path):
        raise FileNotFoundError(f"Файл за шляхом {file_path} не знайдено.")

    with open(file_path, 'r', encoding=encoding) as f:
        return f.read()


def write_text_file(file_path: str, content: str, encoding: str = 'utf-8') -> None:

    with open(file_path, 'w', encoding=encoding) as f:
        f.write(content)