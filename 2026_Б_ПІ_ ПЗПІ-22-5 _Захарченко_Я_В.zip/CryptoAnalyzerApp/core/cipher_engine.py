from collections import Counter
from core.crypto_core import LANG_DATA, clean_text


def solve_caesar(text, lang):
    alphabet = LANG_DATA[lang]["alphabet"]
    m = len(alphabet)
    cleaned = clean_text(text, lang)
    counts = Counter(cleaned)
    best_shift, min_chi2 = 0, float('inf')

    # Автоматичний перебір зсувів
    for s in range(m):
        chi2 = sum(((counts.get(alphabet[(i + s) % m], 0) - len(cleaned) * LANG_DATA[lang]["frequencies"].get(
            alphabet[i], 0)) ** 2)
                   / (len(cleaned) * LANG_DATA[lang]["frequencies"].get(alphabet[i], 0) + 1e-6) for i in range(m))
        if chi2 < min_chi2: min_chi2, best_shift = chi2, s

    decrypted = "".join(
        [alphabet[(alphabet.index(c.lower()) - best_shift) % m] if c.lower() in alphabet else c for c in text])
    return {"text": decrypted, "shift": best_shift}


def solve_vigenere(text, lang):
    alphabet = LANG_DATA[lang]["alphabet"]
    m = len(alphabet)
    cleaned = clean_text(text, lang)
    freqs = LANG_DATA[lang]["frequencies"]

    # 1. Знаходимо довжину ключа
    best_len, min_avg_chi2 = 1, float('inf')
    for length in range(1, min(11, len(cleaned) // 2 + 1)):
        total_chi2 = 0
        for i in range(length):
            sub_slice = cleaned[i::length]
            counts = Counter(sub_slice)
            # Знаходимо найкращий зсув для кожного зрізу
            min_sub_chi2 = min(
                sum(((counts.get(alphabet[(j + s) % m], 0) - len(sub_slice) * freqs.get(alphabet[j], 0)) ** 2)
                    / (len(sub_slice) * freqs.get(alphabet[j], 0) + 1e-6) for j in range(m)) for s in range(m))
            total_chi2 += min_sub_chi2

        avg_chi2 = (total_chi2 / length) * (1 + length * 0.05)
        if avg_chi2 < min_avg_chi2:
            min_avg_chi2, best_len = avg_chi2, length

    # 2. Відновлюємо ключ
    guessed_key = ""
    for i in range(best_len):
        sub_slice = cleaned[i::best_len]
        counts = Counter(sub_slice)
        best_s = min(range(m), key=lambda s: sum(
            ((counts.get(alphabet[(j + s) % m], 0) - len(sub_slice) * freqs.get(alphabet[j], 0)) ** 2)
            / (len(sub_slice) * freqs.get(alphabet[j], 0) + 1e-6) for j in range(m)))
        guessed_key += alphabet[best_s]

    # 3. Дешифруємо текст
    decrypted_chars = []
    for idx, char in enumerate(text):
        if char.lower() in alphabet:
            shift = alphabet.index(guessed_key[idx % best_len])
            orig_idx = alphabet.index(char.lower())
            new_char = alphabet[(orig_idx - shift) % m]
            decrypted_chars.append(new_char.upper() if char.isupper() else new_char)
        else:
            decrypted_chars.append(char)

    return {"text": "".join(decrypted_chars), "key": guessed_key}